//Introducing jQuery
$(function(){
  $('#thumbnails');
   $('.thumbnail');
  $('ul');
  $('ul li');
});

console.log('Hello world');